import pygame
from pygame.sprite import Sprite
""" 
 C�mo poner un temporizador en la pantalla.
  
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
"""

NIVEL_SUELO = 200
COLOR_GRIS = (50, 50, 50)


class Personaje(Sprite):
    "Personaje rectangular que puede caminar y saltar."

    def __init__(self):
        Sprite.__init__(self)
        self.velocidad_inicial = 0
        self.crear_imagen_representacion()

    def crear_imagen_representacion(self):
        self.image = pygame.surface.Surface((30, 30))
        self.image.fill((100, 255, 100))
        self.rect = self.image.get_rect()
        self.rect.center = 160, 200

    def update(self):
        "Actualiza la posición del personaje en base al estado del teclado."

        teclas = pygame.key.get_pressed()

        if teclas[pygame.K_LEFT]:
            self.rect.move_ip(-4, 0)
        
        if teclas[pygame.K_RIGHT]:
            self.rect.move_ip(4, 0)

        # Salto
        if self.rect.bottom >= NIVEL_SUELO:
            self.rect.bottom = NIVEL_SUELO
            
            # solo evalúa un salto si está en el suelo.
            if teclas[pygame.K_UP]:
                self.velocidad_inicial = -10
                self.actualizar_salto()
        else:
            self.actualizar_salto()

    def actualizar_salto(self):
        # si está saltando actualiza su posición
        self.rect.y += self.velocidad_inicial
        self.velocidad_inicial += 0.5

    def draw(self, screen):
        "Muestra al personaje en pantalla."
        screen.blit(self.image, self.rect.center)



# Inicio del programa principal

salir = False
screen = pygame.display.set_mode((320, 240))
personaje = Personaje()

while not salir:

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            salir = True

    personaje.update()

    screen.fill(COLOR_GRIS)
    personaje.draw(screen)
    pygame.display.flip()

    pygame.time.delay(10)
