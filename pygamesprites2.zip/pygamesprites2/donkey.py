import pygame, pygame.font, pygame.event, pygame.draw, string
from pygame.locals import *
import random

NEGRO = (0, 0, 0) 
BLANCO = (255, 255, 255) 
AZUL = (0, 0, 255)
ROJO = (255, 0, 0)
VERDE = (0, 255, 0)
AMARILLO = (255, 255, 0)
CAFE = (117, 75, 13)
 

LARGO_PANTALLA = 800
ALTO_PANTALLA = 620

escaleraSprites = pygame.sprite.Group()
personajed=pygame.image.load("m1.png")
personajei=pygame.image.load("m2.png")
mico=pygame.image.load("mico.png")
barriles=pygame.image.load("barriles.png")
escaleras=pygame.image.load("escalera.png")
escaleras2=pygame.image.load("escalera2.png")
escaleras3=pygame.image.load("escalera3.png")
escaleras4=pygame.image.load("escalera4.png")
escaleras5=pygame.image.load("mescalera.png")

class Protagonista(pygame.sprite.Sprite): 
    """ Esta clase representa la barra inferior que controla el protagonista """
   
   
    cambio_x = 0
    cambio_y = 0

    gravedad = .35
     
    
    nivel = None
    subiendo_escalera = False
    tocando_escalera = False
    subiendo_escalera_desplazamiento = False
    bajando_escalera_desplazamiento = False
    pressing_key_up = False
    can_jump = False
    
 
    def __init__(self): 
        """ Función Constructor  """
         
        
        pygame.sprite.Sprite.__init__(self)    
        largo = 20
        alto = 20
        self.image = personajed
        self.rect = self.image.get_rect() 
    
    def update(self): 
        """ Desplazamos al protagonista. """
        self.check_escalera()
   
        self.calc_grav()
         
     
        self.rect.x += self.cambio_x
         
       
        lista_impactos_bloques = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False)
        
        self.rect.y += self.cambio_y
        
        lista_impactos_bloques = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False) 
        for bloque in lista_impactos_bloques:
 
           
            if self.cambio_y > 0:
                self.rect.bottom = bloque.rect.top 
            elif self.cambio_y < 0:
                self.rect.top = bloque.rect.bottom
 
           
            self.cambio_y = 0


        lista_escaleras = pygame.sprite.spritecollide(self, escaleraSprites, False)
        for bloque in lista_escaleras:
            
            if self.cambio_y > 0 and self.rect.bottom < bloque.rect.top + 2 :
                self.rect.bottom = bloque.rect.top
                self.tocando_escalera = True
                self.can_jump = True
            self.cambio_y = 0
            
        if self.subiendo_escalera:
            if self.subiendo_escalera_desplazamiento:
                self.rect.y -= 2
        if self.tocando_escalera:
            if self.bajando_escalera_desplazamiento:
                self.rect.y += 2
            


            

 
    def calc_grav(self):
        """ Calculamos el efecto de la gravedad. """
        if not self.subiendo_escalera:
            if self.cambio_y == 0:
                self.cambio_y = 1
            else:
                self.cambio_y += self.gravedad


     
            
            if self.rect.y >= ALTO_PANTALLA - self.rect.height and self.cambio_y >= 0:
                self.cambio_y = 0
                self.rect.y = ALTO_PANTALLA - self.rect.height


        
    def saltar(self):
        """ Llamado cuando el usuario pulsa el botón de 'saltar'. """
        
   
        self.check_escalera()
      
        if not self.subiendo_escalera or self.can_jump:
            self.rect.y += 2
            lista_impactos_plataforma = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False)
            self.rect.y -= 2

            if self.cambio_y==0:
                self.cambio_y = -6


    def subir(self):
        """ Llamado cuando el usuario pulsa el botón de 'saltar'. """
        
        self.pressing_key_up = True
        self.check_escalera()
 
        
        if self.subiendo_escalera:
            self.subiendo_escalera_desplazamiento = True
            
       
    def bajar(self):
        
        self.bajando_escalera_desplazamiento = True

    def check_escalera(self):
        self.tocando_escalera = False
        self.subiendo_escalera = False
        self.gravedad = .35
        lista_escaleras = pygame.sprite.spritecollide(self, escaleraSprites, False)
        for bloque in lista_escaleras: 
            self.gravedad = 0
            self.subiendo_escalera = True
            self.tocando_escalera = True
            self.cambio_y = 0
                
        if self.subiendo_escalera and self.pressing_key_up:
            self.subiendo_escalera = True
        elif self.subiendo_escalera and not self.pressing_key_up:
            self.subiendo_escalera = False
        elif not self.subiendo_escalera:
            self.pressing_key_up = False
        
             
    
    def ir_izquierda(self):
        """ Es llamado cuando el usuario pulsa la flecha izquierda """
        self.cambio_x = -3
 
    def ir_derecha(self):
        """ Es llamado cuando el usuario pulsa la flecha derecha """
        self.cambio_x = 3
 
    def stop(self):
        """ Es llamado cuando el usuario abandona el teclado """
        self.cambio_x = 0

class Barril(pygame.sprite.Sprite): 
    """ Esta clase representa la barra inferior que controla el protagonista """
   
    
    cambio_x = 0
    cambio_y = 0

    gravedad = .35
     
   
    nivel = None
    subiendo_escalera = False
    tocando_escalera = False
    subiendo_escalera_desplazamiento = False
    bajando_escalera_desplazamiento = False
    pressing_key_up = False
    can_jump = False
    
   
    def __init__(self): 
        """ Función Constructor  """
         
        
        pygame.sprite.Sprite.__init__(self) 
         
          
        largo = 20
        alto = 20
        self.image = pygame.Surface([largo, alto])

        self.image.fill(AMARILLO)        
   
        
        self.rect = self.image.get_rect() 
    
    def update(self): 
        """ Desplazamos al protagonista. """
        self.check_escalera()
        
        self.calc_grav()
         
       
        self.rect.x += self.cambio_x
         
        
        lista_impactos_bloques = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False)

        self.rect.y += self.cambio_y
         
        
        lista_impactos_bloques = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False) 
        for bloque in lista_impactos_bloques:
 
            
            if self.cambio_y > 0:
                self.rect.bottom = bloque.rect.top 
            elif self.cambio_y < 0:
                self.rect.top = bloque.rect.bottom
 
            
            self.cambio_y = 0


        lista_escaleras = pygame.sprite.spritecollide(self, escaleraSprites, False)
        for bloque in lista_escaleras:
            
            if self.cambio_y > 0 and self.rect.bottom < bloque.rect.top + 2 :
                self.rect.bottom = bloque.rect.top
                self.tocando_escalera = True
                self.can_jump = True
            self.cambio_y = 0
            
        if self.subiendo_escalera:
            if self.subiendo_escalera_desplazamiento:
                self.rect.y -= 2
        if self.tocando_escalera:
            if self.bajando_escalera_desplazamiento:
                self.rect.y += 2
            


            

 
    def calc_grav(self):
        """ Calculamos el efecto de la gravedad. """
        if not self.subiendo_escalera:
            if self.cambio_y == 0:
                self.cambio_y = 1
            else:
                self.cambio_y += self.gravedad


     
            
            if self.rect.y >= ALTO_PANTALLA - self.rect.height and self.cambio_y >= 0:
                self.cambio_y = 0
                self.rect.y = ALTO_PANTALLA - self.rect.height


        
    def saltar(self):
        """ Llamado cuando el usuario pulsa el botón de 'saltar'. """
        
   
        self.check_escalera()
        
        if not self.subiendo_escalera or self.can_jump:
            self.rect.y += 2
            lista_impactos_plataforma = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False)
            self.rect.y -= 2

 
            if self.cambio_y==0:
                self.cambio_y = -6


    def subir(self):
        """ Llamado cuando el usuario pulsa el botón de 'saltar'. """
        
        self.pressing_key_up = True
        self.check_escalera()
  
        if self.subiendo_escalera:
            self.subiendo_escalera_desplazamiento = True
            
       
    def bajar(self):
        
        self.bajando_escalera_desplazamiento = True

    def check_escalera(self):
        self.tocando_escalera = False
        self.subiendo_escalera = False
        self.gravedad = .35
        lista_escaleras = pygame.sprite.spritecollide(self, escaleraSprites, False)
        for bloque in lista_escaleras: 
            self.gravedad = 0
            self.subiendo_escalera = True
            self.tocando_escalera = True
            self.cambio_y = 0
                
        if self.subiendo_escalera and self.pressing_key_up:
            self.subiendo_escalera = True
        elif self.subiendo_escalera and not self.pressing_key_up:
            self.subiendo_escalera = False
        elif not self.subiendo_escalera:
            self.pressing_key_up = False
        
             
   
    def ir_izquierda(self):
        """ Es llamado cuando el usuario pulsa la flecha izquierda """
        self.cambio_x = -5
 
    def ir_derecha(self):
        """ Es llamado cuando el usuario pulsa la flecha derecha """
        self.cambio_x = 5
 
    def stop(self):
        """ Es llamado cuando el usuario abandona el teclado """
        self.cambio_x = 0
                    
class Plataforma(pygame.sprite.Sprite):
    """ Plataforma sobre la que el usuario puede saltar. """
    
 
    def __init__(self, largo, alto ):
        """  Constructor de plataforma. Asume su construcción cuando el usuario le haya pasado 
            un array de 5 números, tal como se ha definido al principio de este código. """
        pygame.sprite.Sprite.__init__(self)
         
        self.image = pygame.Surface([largo, alto])
        self.image.fill(ROJO)    
                 
        self.rect = self.image.get_rect()

class Escalera(pygame.sprite.Sprite):
    """ Plataforma sobre la que el usuario puede saltar. """
 
    def __init__(self, largo, alto ):
        """  Constructor de plataforma. Asume su construcción cuando el usuario le haya pasado 
            un array de 5 números, tal como se ha definido al principio de este código. """
        pygame.sprite.Sprite.__init__(self)
         
        self.image = pygame.Surface([largo, alto])
                 
        self.rect = self.image.get_rect()

class Tiempo(pygame.sprite.Sprite):
    def __init__(self):
        
    
        pygame.sprite.Sprite.__init__(self) 
         
        
        largo = 20
        alto = 20
        self.image = pygame.Surface([largo, alto])

        self.image.fill(BLANCO)
   
        
        self.rect = self.image.get_rect() 

class Martillo(pygame.sprite.Sprite):
    def __init__(self):
        
       
        pygame.sprite.Sprite.__init__(self) 
         
        
        largo = 20
        alto = 20
        self.image = pygame.Surface([largo, alto])

        self.image.fill(VERDE)
   
        self.rect = self.image.get_rect() 

  
class Nivel(object):
    """ Esta es una súper clase genérica usada para definir un nivel.
        Crea una clase hija específica para cada nivel con una info específica. """
         
    def __init__(self, protagonista):
        """ Constructor. Requerido para cuando las plataformas móviles colisionan con el protagonista. """
        self.listade_plataformas = pygame.sprite.Group()
        self.listade_enemigos = pygame.sprite.Group()
        self.protagonista = protagonista
         
   
    def update(self):
        """ Actualizamos todo en este nivel."""
        self.listade_plataformas.update()
        self.listade_enemigos.update()
     
    def draw(self, pantalla):
        """ Dibujamos todo en este nivel. """
         
        
        pantalla.fill(NEGRO)
                   
       
        self.listade_plataformas.draw(pantalla)
        self.listade_enemigos.draw(pantalla)

       
 
     

class Nivel_01(Nivel):
    """ Definición para el nivel 1. """
 
    def __init__(self, protagonista):
        """ Creamos el nivel 1. """
         
       
        Nivel.__init__(self, protagonista)
         
        
        nivel = [ [ 900,10,600,610],[ 900,10,500,610],[ 900,10,400,610],[ 900,10,300,610],[ 900,10,200,610],[ 900,10,100,610],[ 900,10,50,610],[ 900,10,50,610],[ 900,10,0,610],
                  [100, 20, 720, 495],[100, 20, 650, 496],[100, 20, 595, 497],[100, 20, 550, 498],[100, 20, 500, 499],[100, 20, 450, 500],[80, 20, 400, 501],[80, 20, 280, 502],[80, 20, 200, 503],[80, 20, 150, 504],[80, 20, 100, 505],[80, 20, 50, 506],
                  [100, 20, 720, 300],[100, 20, 650,301],[100, 20, 595,302],[100, 20, 550,303],[100, 20, 500,304],[100, 20, 450,305],[100, 20, 400,306],[100, 20, 395,307],[110, 20,250,308],[100, 20, 170,309],[100, 20, 120,310],[100, 20, 55,311],
                  [100, 20, 0, 395],[100, 20, 80, 396],[100, 20, 110, 397], [100, 20, 150, 398],[100, 20, 200, 399],[100, 20, 250, 400],[100, 20, 300,401],[100, 20, 350,402],[100, 20, 400,403],[100, 20, 540,404],[100, 20, 600,405],[100, 20, 630,406],
                  [100, 20, 0, 210],[100, 20, 80, 211],[100, 20, 110, 212], [100, 20, 150, 213], [100, 20, 200, 214],[100, 20, 250, 215],[100, 20, 300, 216],[100, 20, 350, 217],[100, 20, 400, 218],[100, 20, 540, 219],[100, 20, 600, 220],[100, 20, 630, 221],
                  [100, 20, 720, 125],[100, 20, 650, 126],[100, 20, 595, 127],[100, 20, 550, 128],[100, 20, 550, 129],[100, 20, 500, 130],[100, 20, 450, 131],[100, 20, 400, 132],[100, 20, 350, 133],[100, 20, 220, 134],[100, 20, 150, 135],[100, 20, 100, 136],[100, 20, 50, 137],
                  [200, 22, 0, 60],[200, 22, 200, 60],[200, 22, 440 , 60],[200, 22, 500, 60], [200, 22, 520, 60],[100, 22, 700, 60]
                  ]

        # Iteramos sobre el array anterior y añadimos plataformas
        for plataforma in nivel:
            bloque = Plataforma(plataforma[0], plataforma[1])
            bloque.rect.x = plataforma[2]
            bloque.rect.y = plataforma[3]
            bloque.protagonista = self.protagonista
            self.listade_plataformas.add(bloque)


            

class Nivel_02(Nivel):
    """ Definición para el nivel 1. """
 
    def __init__(self, protagonista):
        """ Creamos el nivel 1. """
         
       
        Nivel.__init__(self, protagonista)
         
        
        nivel = [ [ 900,10,600,610],[ 900,10,500,610],[ 900,10,400,610],[ 900,10,300,610],[ 900,10,200,610],[ 900,10,100,610],[ 900,10,50,610],[ 900,10,50,610],[ 900,10,0,610],
                  [100, 20, 720, 495],[100, 20, 650, 496],[100, 20, 595, 497],[100, 20, 550, 498],[100, 20, 500, 499],[100, 20, 450, 500],[80, 20, 400, 501],[80, 20, 280, 502],[80, 20, 200, 503],[80, 20, 150, 504],[80, 20, 100, 505],[80, 20, 50, 506],                              
                  [100, 20, 720, 300],[100, 20, 650,301],[100, 20, 595,302],[100, 20, 550,303],[100, 20, 500,304],[100, 20, 450,305],[100, 20, 400,306],[100, 20, 395,307],[110, 20,250,308],[100, 20, 170,309],[100, 20, 120,310],[100, 20, 55,311],
                  [100, 20, 0, 395],[100, 20, 80, 396],[100, 20, 110, 397], [100, 20, 150, 398],[100, 20, 200, 399],[100, 20, 250, 400],[100, 20, 300,401],[100, 20, 350,402],[100, 20, 400,403],[100, 20, 540,404],[100, 20, 600,405],[100, 20, 650,406],
                  [100, 20, 0, 210],[100, 20, 80, 211],[100, 20, 110, 212], [100, 20, 150, 213], [100, 20, 200, 214],[100, 20, 250, 215],[100, 20, 300, 216],[100, 20, 350, 217],[100, 20, 400, 218],[100, 20, 540, 219],[100, 20, 600, 220],[100, 20, 650, 221],
                  [100, 20, 720, 125],[100, 20, 650, 126],[100, 20, 595, 127],[100, 20, 550, 128],[100, 20, 550, 129],[100, 20, 500, 130],[100, 20, 450, 131],[100, 20, 400, 132],[100, 20, 350, 133],[100, 20, 220, 134],[100, 20, 150, 135],[100, 20, 100, 136],[100, 20, 50, 137],
                  [200, 22, 0, 60],[200, 22, 200, 60],[200, 22, 440 , 60],[200, 22, 500, 60], [200, 22, 520, 60],[100, 22, 700, 60]
                  ]
 
        
        for plataforma in nivel:
            bloque = Plataforma(plataforma[0], plataforma[1])
            bloque.rect.x = plataforma[2]
            bloque.rect.y = plataforma[3]
            bloque.protagonista = self.protagonista
            self.listade_plataformas.add(bloque)  



            
def get_key():
  while 1:
    event = pygame.event.poll()
    if event.type == KEYDOWN:
      return event.key
    else:
      pass

def display_box(screen, message):
  "Print a message in a box in the middle of the screen"
  fontobject = pygame.font.Font(None,18)
  pygame.draw.rect(screen, (0,0,0),
                   ((screen.get_width() / 2) - 100,
                    (screen.get_height() / 2) - 10,
                    200,20), 0)
  pygame.draw.rect(screen, (255,255,255),
                   ((screen.get_width() / 2) - 102,
                    (screen.get_height() / 2) - 12,
                    204,24), 1)
  if len(message) != 0:
    screen.blit(fontobject.render(message, 1, (255,255,255)),
                ((screen.get_width() / 2) - 100, (screen.get_height() / 2) - 10))
  pygame.display.flip()

def ask(screen, question):
  "ask(screen, question) -> answer"
  pygame.font.init()
  s = ""
  current_string = []
  for i in current_string:
        s += i
  display_box(screen, question + ": " + s)
  while 1:
    inkey = get_key()
    if inkey == K_BACKSPACE:
      current_string = current_string[0:-1]
    elif inkey == K_RETURN:
      break
    elif inkey == K_MINUS:
      current_string.append("_")
    elif inkey <= 127:
      current_string.append(chr(inkey))
    for i in current_string:
        s += i
        
    display_box(screen, question + ": " + s)
    for i in current_string:
        s += i
  return s


 
def main():
    ganar = 0
    """ Programa Principal """
    pygame.init()
    pygame.display.set_caption("DonKey Kong")

   
    screen = pygame.display.set_mode((320,240))
    nombre="Jugador: " + ask(screen, "Name")
    

 
    minutos=0
    segundos=0
    numero_de_fotogramas = 0
    tasa_fotogramas = 20
    instante_de_partida = 120
    
    
    
    dimensiones = [LARGO_PANTALLA, ALTO_PANTALLA] 
    pantalla = pygame.display.set_mode(dimensiones) 

    
    protagonista = Protagonista()
 
   
    listade_niveles = []
    listade_niveles.append(Nivel_01(protagonista))
    listade_niveles.append(Nivel_02(protagonista))
     
    
    nivel_actual_no = 0
    nivel_actual = listade_niveles[nivel_actual_no]
     
    lista_sprites_activos = pygame.sprite.Group()
    protagonista.nivel = nivel_actual
     
    protagonista.rect.x = 0
    protagonista.rect.y = 500
    lista_sprites_activos.add(protagonista)
         
    
    hecho = False
       
   
    reloj = pygame.time.Clock()

    escalerasPositions = [[34, 122, 363,500],[34, 122,500,400],[34, 122,355,300],[34, 122,500,192],[34, 122,315,105],[34, 122,402,35],[34, 122,200,238],[34, 122,250,370]]

    
    power=False
    puntos=0
    powertmp=0
    
    
    var=0
    var200=0
    var400=0
    var600=0
    var800=0
    var1000=0
    vardon=0
    tmp=0
    barril0 = Barril()
    barril200 = Barril()
    barril400 = Barril()
    barril600 = Barril()
    barril800 = Barril()
    barril1000 = Barril()
    donkey = Barril()


    tiempo = Tiempo()
    martillo = Martillo()

    listade_niveles.append(Nivel_01(tiempo))
    listade_niveles.append(Nivel_02(tiempo))
    tiempo.nivel = nivel_actual
    tiempo.rect.x = random.randint(2,800)
    tiempo.rect.y = random.randint(80,620)
    lista_sprites_activos.add(tiempo)

    listade_niveles.append(Nivel_01(martillo))
    listade_niveles.append(Nivel_02(martillo))
    martillo.nivel = nivel_actual
    martillo.rect.x = random.randint(2,800)
    martillo.rect.y = random.randint(80,620)
    lista_sprites_activos.add(martillo)
    
    for plataforma in escalerasPositions:
        bloque = Escalera(plataforma[0], plataforma[1])
        bloque.rect.x = plataforma[2]
        bloque.rect.y = plataforma[3]
        bloque.protagonista = protagonista
        bloque.barril=barril0
        bloque.barril=barril200
        bloque.barril=barril400
        bloque.barril=barril600
        bloque.barril=barril800
        bloque.barril=barril1000
        bloque.barril=barril1000
        bloque.barril=donkey
        bloque.tiempo=tiempo
        bloque.martillo=martillo
        escaleraSprites.add(bloque)
       
    # -------- Bucle Principal del Programa ----------- 
    while not hecho:
        for evento in pygame.event.get(): # El usuario realizó alguna acción 
            if evento.type == pygame.QUIT: # Si el usuario hizo click en salir
                hecho = True # Marcamos como hecho y salimos de este bucle
                 
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_LEFT:
                    protagonista.ir_izquierda()
                    protagonista.image=personajei
                if evento.key == pygame.K_RIGHT:
                    protagonista.ir_derecha()
                    protagonista.image=personajed
                if evento.key == pygame.K_UP:
                    protagonista.subir()
                if evento.key == pygame.K_b:
                    protagonista.saltar()
                if evento.key == pygame.K_DOWN:
                    protagonista.bajar()

            if evento.type == pygame.KEYUP:
                if evento.key == pygame.K_UP:
                    protagonista.subiendo_escalera_desplazamiento = False
                if evento.key == pygame.K_DOWN:
                    protagonista.bajando_escalera_desplazamiento = False
                    protagonista.pressing_key_up = True
                    
                if evento.key == pygame.K_LEFT and protagonista.cambio_x < 0: 
                    protagonista.stop()
                if evento.key == pygame.K_RIGHT and protagonista.cambio_x > 0:
                    protagonista.stop()

       

        if  tmp==1:
            listade_niveles.append(Nivel_01(donkey))
            listade_niveles.append(Nivel_02(donkey))
            donkey.nivel = nivel_actual
            donkey.rect.x = 778
            donkey.rect.y = 20
            lista_sprites_activos.add(donkey)
        if  tmp==1:
            listade_niveles.append(Nivel_01(barril0))
            listade_niveles.append(Nivel_02(barril0))
            barril0.nivel = nivel_actual
            barril0.rect.x = 778
            barril0.rect.y = 100
            lista_sprites_activos.add(barril0)
        elif tmp==200:
            listade_niveles.append(Nivel_01(barril200))
            listade_niveles.append(Nivel_02(barril200))
            barril200.nivel = nivel_actual
            barril200.rect.x = 778
            barril200.rect.y = 100
            lista_sprites_activos.add(barril200)
        if  tmp==400:
            listade_niveles.append(Nivel_01(barril400))
            listade_niveles.append(Nivel_02(barril400))
            barril400.nivel = nivel_actual
            barril400.rect.x = 778
            barril400.rect.y = 100
            lista_sprites_activos.add(barril400)
        elif tmp==600:
            listade_niveles.append(Nivel_01(barril600))
            listade_niveles.append(Nivel_02(barril600))
            barril600.nivel = nivel_actual
            barril600.rect.x = 778
            barril600.rect.y = 100
            lista_sprites_activos.add(barril600)
        if  tmp==800:
            listade_niveles.append(Nivel_01(barril800))
            listade_niveles.append(Nivel_02(barril800))
            barril800.nivel = nivel_actual
            barril800.rect.x = 778
            barril800.rect.y = 100
            lista_sprites_activos.add(barril800)
        elif tmp==1000:
            listade_niveles.append(Nivel_01(barril1000))
            listade_niveles.append(Nivel_02(barril1000))
            barril1000.nivel = nivel_actual
            barril1000.rect.x = 778
            barril1000.rect.y = 100
            lista_sprites_activos.add(barril1000)
        vardon=var
        if var==0:
            barril0.ir_izquierda()
        elif var==1:
            barril0.ir_derecha()
        if var200==0:
            barril200.ir_izquierda()
        elif var200==1:
            barril200.ir_derecha()
        if var400==0:
            barril400.ir_izquierda()
        elif var400==1:
            barril400.ir_derecha()
        if var600==0:
            barril600.ir_izquierda()
        elif var600==1:
            barril600.ir_derecha()
        if var800==0:
            barril800.ir_izquierda()
        elif var800==1:
            barril800.ir_derecha()
        if var1000==0:
            barril1000.ir_izquierda()
        elif var1000==1:
            barril1000.ir_derecha() 
        if vardon==0:
            donkey.ir_izquierda()
        elif vardon==1:
            donkey.ir_derecha()
          
        
 
        lista_sprites_activos.update()
         
        
        nivel_actual.update()
         
 
        if protagonista.rect.right > LARGO_PANTALLA:
            protagonista.rect.right = LARGO_PANTALLA
            
       
        if protagonista.rect.left < 0:
            protagonista.rect.left = 0

        
            
        if barril0.rect.right > 778:
            var=0
        elif barril200.rect.right > 778:
            var200=0
        elif barril400.rect.right > 778:
            var400=0
        elif barril600.rect.right > 778:
            var600=0
        elif barril800.rect.right > 778:
            var800=0
        elif barril1000.rect.right > 778:
            var1000=0
        elif donkey.rect.right > 778:
            vardon=0
        
        if barril0.rect.left < 2:
            var=1
        elif barril200.rect.left < 2:
            var200=1
        elif barril400.rect.left < 2:
            var400=1
        elif barril600.rect.left < 2:
            var600=1
        elif barril800.rect.left < 2:
            var800=1
        elif barril1000.rect.left < 2:
            var1000=1
        elif donkey.rect.left < 2:
            vardon=1

       
        if (minutos==0 and segundos==1) or ((protagonista.rect.colliderect(barril0) or protagonista.rect.colliderect(barril200) or protagonista.rect.colliderect(barril400) or protagonista.rect.colliderect(barril600) or protagonista.rect.colliderect(barril800) or protagonista.rect.colliderect(barril1000)) and power==False):
            main()

        if protagonista.rect.colliderect(tiempo):
            instante_de_partida+=30
            tiempo.rect.x = -100
            tiempo.rect.x = -100

        if protagonista.rect.colliderect(martillo):
            power=True
            martillo.rect.x = -100
            martillo.rect.x = -100

        
        if powertmp>500:
            power=False

       
        donkey.image.fill(ROJO)
        if power==True:
            barril0.image.fill(AZUL)
            barril200.image.fill(AZUL)
            barril400.image.fill(AZUL)
            barril600.image.fill(AZUL)
            barril800.image.fill(AZUL)
            barril1000.image.fill(AZUL)

            powertmp+=1
        else:
            barril0.image.fill(AMARILLO)
            barril200.image.fill(AMARILLO)
            barril400.image.fill(AMARILLO)
            barril600.image.fill(AMARILLO)
            barril800.image.fill(AMARILLO)
            barril1000.image.fill(AMARILLO)
           

          
        if power==True and protagonista.rect.colliderect(barril0):
            barril0.rect.x = 778
            barril0.rect.y = 100
            puntos+=10
        if power==True and protagonista.rect.colliderect(barril200):
            barril200.rect.x = 778
            barril200.rect.y = 100
            puntos+=10
        if power==True and protagonista.rect.colliderect(barril400):
            barril400.rect.x = 778
            barril400.rect.y = 100
            puntos+=10
        if power==True and protagonista.rect.colliderect(barril600):
            barril600.rect.x = 778
            barril600.rect.y = 100
            puntos+=10
        if power==True and protagonista.rect.colliderect(barril800):
            barril800.rect.x = 778
            barril800.rect.y = 100
            puntos+=10
        if power==True and protagonista.rect.colliderect(barril1000):
            barril1000.rect.x = 778
            barril1000.rect.y = 100
            puntos+=10
    
      
        if barril0.rect.bottom==610 and barril0.rect.right==778:
            barril0.rect.x = 778
            barril0.rect.y = 100
            donkey.rect.x = 778
            donkey.rect.y = 20
            
        if barril200.rect.bottom==610 and barril200.rect.right==778:
            barril200.rect.x = 778
            barril200.rect.y = 100
        if barril400.rect.bottom==610 and barril400.rect.right==778:
            barril400.rect.x = 778
            barril400.rect.y = 100
        if barril600.rect.bottom==610 and barril600.rect.right==778:
            barril600.rect.x = 778
            barril600.rect.y = 100
        if barril800.rect.bottom==610 and barril800.rect.right==778:
            barril800.rect.x = 778
            barril800.rect.y = 100
        if barril1000.rect.bottom==610 and barril1000.rect.right==778:
            barril1000.rect.x = 778
            barril1000.rect.y = 100
        
       
        if (ganar == 0 ):
            nivel_actual.draw(pantalla)
            lista_sprites_activos.draw(pantalla)
            pantalla.blit(barriles,(0,19))
            pantalla.blit(escaleras,(363,500))
            pantalla.blit(escaleras2,(500,400))
            pantalla.blit(escaleras2,(355,300))
            pantalla.blit(escaleras3,(500,192))
            pantalla.blit(escaleras3,(315,105))
            pantalla.blit(escaleras4,(402,35))
            pantalla.blit(escaleras5,(200,238))
            pantalla.blit(escaleras5,(250,370))

        if (ganar == 1 ):
            nivel_actual.draw(pantalla)
            lista_sprites_activos.draw(pantalla)
            pantalla.blit(barriles,(0,19))
            pantalla.blit(escaleras,(363,500))
            pantalla.blit(escaleras2,(500,400))
            pantalla.blit(escaleras2,(355,300))
            pantalla.blit(escaleras3,(500,192))
            pantalla.blit(escaleras3,(315,105))
            pantalla.blit(escaleras4,(402,35))
            #pantalla.blit(escaleras5,(200,238))
            #pantalla.blit(escaleras5,(250,370))         
         
        


        fuente = pygame.font.Font(None, 20)
        texto1 = fuente.render(str(nombre), 0, (255, 255, 255))
        pantalla.blit(texto1, (0,0))
        
        
     
    
        segundos_totales = instante_de_partida - (numero_de_fotogramas // tasa_fotogramas)
        if segundos_totales < 0:
            segundos_totales = 0
         
        
        minutos = segundos_totales // 60
         
        
        segundos = segundos_totales % 60
         
        
        texto_de_salida = "tiempo restante: {0:02}:{1:02}".format(minutos, segundos)
        
       

        texto1 = fuente.render(str(texto_de_salida), 0, (255, 255, 255))
        pantalla.blit(texto1, (200,0))

        texto2 = fuente.render("Puntos: "+str(puntos), 0, (255, 255, 255))
        pantalla.blit(texto2, (400,0))

       
        numero_de_fotogramas = numero_de_fotogramas + 1

        pygame.display.update()

        
        if (protagonista.rect.colliderect(donkey) and (ganar == 1)):
            imagengana = pygame.image.load("win.png")
            pantalla.blit(imagengana,(20,20))
            ganar += 1
            
            
        if (protagonista.rect.colliderect(donkey)and (ganar == 0)):
            ganar = 1
            tiempo.rect.x = random.randint(2,800)
            tiempo.rect.y = random.randint(80,620)
            martillo.rect.x = random.randint(2,800)
            martillo.rect.y = random.randint(80,620)
            donkey.rect.x = 389
            donkey.rect.y = 20
            protagonista.rect.x = 0
            protagonista.rect.y = 500
            
         
   
        reloj.tick(60) 
       
       
        pygame.display.flip()

        tmp+=1
      
    
    pygame.quit()
 
if __name__ == "__main__":
    main()
