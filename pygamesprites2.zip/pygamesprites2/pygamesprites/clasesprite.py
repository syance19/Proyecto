import pygame

class jugador(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.rect.x=x
        self.rect.y=y
    def cambiovelocidad(self,x,y):
        self.cambio_x+=x
        self.cambio_y+=y
    def update(self):
        self.rect.x+=self.cambio_x
        self.pygame.image.load("m1.png")
        self.pygame.image.load("m2.png")
