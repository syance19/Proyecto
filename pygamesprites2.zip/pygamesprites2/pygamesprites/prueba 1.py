import pygame,random,sys
from pygame.locals import *
from clasesprite import*


 


pygame.init()
pantalla = pygame.display.set_mode((800,500))
pygame.display.set_caption("Don King Kong")
x,y=0,0
moverx,movery=0,0
reloj=pygame.time.Clock()

class sprite:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.height=50
        self.widht=50
        self.i1=pygame.image.load("m1.png")
        self.i2=pygame.image.load("m2.png")
        self.timeTarget=10
        self.timeNum=0
        self.currentImage=0
    def update(self):
        self.timeNum+=1
        if(self.timeNum==self.timeTarget):
            if (self.currentImage==0):
                self.currentImage+=1
            else:
                self.currentImage=0
            self.timeNum=0
        self.render1()
    def render1(self):
        if (self.currentImage==0):
            ventana.blit(self.i1,(self.x,self.y))
        else:
            ventana.blit(self.i2,(self.x,self.y))
        
            

 


    

    obstaculo1=pygame.Rect(0,400,400,0)
    
    mario=sprite(100,140)

while True:
        for eventos in pygame.event.get():
            if eventos.type ==QUIT:
                sys.exit(0)
        pulsar=pygame.key.get_pressed()
        oldx=sprite1.rect.left
        oldy=sprite1.rect.top
        if pulsar[K_UP]:
            sprite1.rect.top-=5
        if pulsar[K_DOWN]:
            sprite1.rect.top+= 5
        if pulsar[K_LEFT]:
            sprite1.rect.left-= 5
        if pulsar[K_RIGHT]:
            sprite1.rect.left+= 5
        if obstaculo1.colliderect(sprite1):
            sprite1.rect.left=oldx
            sprite1.rect.top=oldy
        
        
        
        reloj.tick(25)
        pantalla.fill((0,0,0))
        mario.x+=moverx
        mario.y+=movery
        mario.update()
        pygame.draw.rect(pantalla,(255,255,255),obstaculo1)
        pygame.display.update()
  
if __name__ == '__main__':
    main()
